<?php

$conta  = 3;

while ($conta != 16) {


echo $conta ."<br />";

$conta++;


}

echo "fine  ciclo while";


?>