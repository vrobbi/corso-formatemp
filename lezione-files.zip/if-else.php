<?php

echo "<h2> if   else </h2>";

$nome = "Francesco";

if ($nome === "Roberto") {


   

echo $nome ." - insegnante";


} else {

echo $nome ." - Allievo";

}


?>