<?php

echo "<h2> ciclo for </h2>";



for ($incrementa = 5; $incrementa!=20; $incrementa++) {

if($incrementa==9) {
echo "INCREMENTA E ARRIVATO A " .   $incrementa  .  "<br />";

}else {
echo "il valore non è 9 <br />";

}
   

echo $incrementa ."<br />";


}


?>