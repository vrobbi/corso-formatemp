<?php

echo "<h2> ciclo for </h2>";



for ($incrementa = 5; $incrementa!=20; $incrementa++) {

if($incrementa==9) {
echo "esco dal ciclo for <br />";
exit;

}
   

echo $incrementa ."<br />";


}

echo "fine dello script";


?>