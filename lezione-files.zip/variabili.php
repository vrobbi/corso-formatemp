<?php

echo "<center><h2> variabili </h2></center>";

$somma = 470;
$numero = 30;


$nome ="francesco ";


$saluto ="ciaoo ";



echo $nome    .   "<br />";

echo $saluto .   "<br />";


echo $numero + $somma;

?>