<?php // File: /ex06.php

// Importo i namespaces e gli assegno un Alias
use Framework\Core\Main\MyClass as MainMy;
use Framework\Core\Main\Libs\MyClass as LibsMy;

// Includo i file
require_once('Framework/Core/Main/MyClass.php');
require_once('Framework/Core/Main/Libs/MyClass.php');

// UNQUALIFIED NAME...
$objOneMain = New MainMy();
$objOneLib = New LibsMy();
