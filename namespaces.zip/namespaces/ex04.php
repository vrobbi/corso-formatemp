<?php // File: /ex04.php

// Includo i file
require_once('Framework/Core/Main/MyClass.php');
require_once('Framework/Core/Main/Libs/MyClass.php');

// FULLY-QUALIFIED NAME...
$objOneMain = New \Framework\Core\Main\MyClass();
$objOneLib = New \Framework\Core\Main\Libs\MyClass();
