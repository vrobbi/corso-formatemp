<?php // File: /ex02.php

// Dichiaro il namespace
namespace Framework\Core\Main\Libs;

// Includo i file
require_once('Framework/Core/Main/MyClass.php');
require_once('Framework/Core/Main/Libs/MyClass.php');

// UNQUALIFIED NAME...
$objOne = New MyClass();
