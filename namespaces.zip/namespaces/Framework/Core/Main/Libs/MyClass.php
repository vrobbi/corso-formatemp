<?php // File 2: /Framework/Core/Main/Libs/MyClass.php

namespace Framework\Core\Main\Libs;

Class MyClass {
    public function __construct() {
        echo '<p>LIBS: MyClass ready!</p>';
    }
}