<?php // File 1: /Framework/Core/Main/MyClass.php

namespace Framework\Core\Main;

Class MyClass {
    public function __construct() {
        echo '<p>MAIN: MyClass ready!</p>';
    }
}
