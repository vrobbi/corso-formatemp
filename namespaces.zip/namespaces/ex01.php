<?php // File: /ex01.php

// Includo i file
require_once('Framework/Core/Main/MyClass.php');
require_once('Framework/Core/Main/Libs/MyClass.php');

// Creo l'oggetto
$objOne = New MyClass();