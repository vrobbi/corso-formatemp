<?php // File: /ex05.php

// Importo il namespace e gli assegno un Alias
use Framework\Core\Main as Main;

// Includo i file
require_once('Framework/Core/Main/MyClass.php');
require_once('Framework/Core/Main/Libs/MyClass.php');

// QUALIFIED NAME...
$objOneMain = New Main\MyClass();
$objOneLib = New Main\Libs\MyClass();
