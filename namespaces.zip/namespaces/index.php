<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

if (isset($_GET['file'])) {
    $file = $_GET['file'] . '.php';
}

?>
<html>
<head>
    <title>Esempi Namespaces Php</title>
    <style>
        * {
            padding:0;
            margin:0;
            font-family: Lucida Grande, Lucida Sans, Arial, sans-serif;
        }
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
        }
        #colSx {
            width: calc(50% - 2em);
            height: calc(100% - 2em);
            float: left;
            padding: 1em;
            background: #555;
        }
        #colDx {
            width: calc(50% - 2em);
            height: calc(100% - 2em);
            float: right;
            padding: 1em;
        }
        nav li {
            list-style: none;
        }
        nav li a {
            display: block;
            padding: 0.5em;
            margin: 0 0 0.5em 0;
            border:1px solid #000;
            text-decoration: none;
            color: #FFF;
            background: #333;
        }
        nav li a:hover {
            background: #222;
        }
        #code {
            padding: 1em;
            background: #ddd;
        }
        #code * {
            font-family: "Courier New", Courier, monospace !important;
        }

    </style>
</head>
<body>
    <div id="colSx">
        <nav>
        <ul>
            <li><a href="?file=ex01">Ex. 01 - No Namespace (error!)</a></li>
            <li><a href="?file=ex02">Ex. 02 - Unqualified name</a></li>
            <li><a href="?file=ex03">Ex. 03 - Qualified name</a></li>
            <li><a href="?file=ex04">Ex. 04 - Fully-qualified name</a></li>
            <li><a href="?file=ex05">Ex. 05 - use + namespace</a></li>
            <li><a href="?file=ex06">Ex. 06 - use + class alias</a></li>
        </ul>
        </nav>
        <div id="code">
            <?php
            if( isset($file) ) {
                highlight_file($file);
            }
            ?>
        </div>
    </div>
    <div id="colDx">
        <?php
        if( isset($file) ) {
            echo "<h2>{$file}</h2>";
            include($file);
        }
        ?>
    </div>
</body>
</html>